import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Resvg } from '@resvg/resvg-js';

// Editable layout source. Generated images stay separate from Korean type.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const config = JSON.parse(fs.readFileSync(path.join(root, 'template/content.json'), 'utf8'));
const C = config.colors;
const FONT = 'Noto Sans KR';
const fontFiles = [
  process.env.MAGAZINE_FONT_REGULAR || 'C:/Windows/Fonts/NotoSansKR-Regular.ttf',
  process.env.MAGAZINE_FONT_BOLD || 'C:/Windows/Fonts/NotoSansKR-Bold.ttf',
].filter(p => fs.existsSync(p));
if (fontFiles.length < 2) throw new Error('Set MAGAZINE_FONT_REGULAR and MAGAZINE_FONT_BOLD to Korean font files.');
const renderOptions = { font: { fontFiles, loadSystemFonts: false, defaultFontFamily: FONT }, textRendering: 2 };
const esc = s => String(s).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const W = config.canvas.width, H = config.canvas.height;
const cache = new Map();
const audits = [];
let currentCard = '';
function data(file) {
  if (!cache.has(file)) {
    const ext = path.extname(file).toLowerCase();
    const mime = ext === '.svg' ? 'image/svg+xml' : 'image/png';
    cache.set(file, `data:${mime};base64,${fs.readFileSync(path.join(root, file)).toString('base64')}`);
  }
  return cache.get(file);
}
function svg(body, width = W, height = H) {
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">${body}</svg>`;
}
const rect = (x,y,w,h,fill,rx=0,extra='') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" ${extra}/>`;
const line = (x1,y1,x2,y2,color,width=1,extra='') => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}" ${extra}/>`;
function text(x,y,str,size=32,weight=400,fill=C.ink,opt={}) {
  let actualSize = size;
  let markup, bounds;
  const anchor = opt.anchor || 'start';
  const family = opt.family || FONT;
  do {
    markup = `<text x="${x}" y="${y}" font-family="${family}" font-size="${actualSize}" font-weight="${weight}" fill="${fill}" text-anchor="${anchor}" letter-spacing="${opt.spacing || 0}">${esc(str)}</text>`;
    bounds = new Resvg(svg(markup), renderOptions).getBBox();
    if (!opt.maxWidth || !bounds || bounds.width <= opt.maxWidth || actualSize <= (opt.minSize || size * .8)) break;
    actualSize -= 1;
  } while (true);
  if (bounds) audits.push({card:currentCard,text:str,size:actualSize,x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height,maxWidth:opt.maxWidth || null});
  return markup;
}
function lines(x,y,arr,size,leading,weight=400,fill=C.ink,maxWidth=936) {
  return arr.map((s,i)=>text(x,y+i*leading,s,size,weight,fill,{maxWidth})).join('');
}
function image(file,x,y,w,h,r=0,fit='slice',pos='xMidYMid') {
  const id = `clip-${Math.random().toString(36).slice(2)}`;
  return `<defs><clipPath id="${id}">${rect(x,y,w,h,'white',r)}</clipPath></defs><image x="${x}" y="${y}" width="${w}" height="${h}" preserveAspectRatio="${pos} ${fit}" clip-path="url(#${id})" href="${data(file)}"/>`;
}
const poses = {front:[0,0],side:[1,0],back:[2,0],sleepy:[0,1],puzzled:[1,1],surprised:[2,1],scroll:[0,2],notes:[1,2],calm:[2,2]};
const sheet = fs.readFileSync(path.join(root,'brand/tteumi-master-sheet.png'));
const sheetW=sheet.readUInt32BE(16), sheetH=sheet.readUInt32BE(20);
function pose(name,x,y,w,h) {
  const [col,row]=poses[name], cw=sheetW/3, ch=sheetH/3;
  // The hand-drawn source is not a perfectly aligned grid. Exclude neighbours.
  const windows={notes:[430,837,320,410],calm:[800,836,454,418]};
  const box=windows[name] || [col*cw,row*ch,cw,ch];
  const id=`pose-clip-${name}-${x}-${y}`;
  return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${box.join(' ')}" overflow="hidden"><defs><clipPath id="${id}">${rect(...box,'white')}</clipPath></defs><image width="${sheetW}" height="${sheetH}" clip-path="url(#${id})" href="${data('brand/tteumi-master-sheet.png')}"/></svg>`;
}
function header(page,dark=false) {
  const f=dark?C.paper:C.ink;
  return text(72,99,config.brand.name,62,700,f)+text(153,94,config.brand.latin,25,700,f,{spacing:3})+
    text(1008,70,config.brand.category,21,500,f,{anchor:'end',spacing:2})+
    text(1008,104,`ISSUE ${config.brand.issue}  /  ${String(page).padStart(2,'0')}`,21,400,f,{anchor:'end',spacing:1})+
    line(72,128,1008,128,f,1,'opacity=".35"');
}
function footer(page,dark=false,note='') {
  const f=dark?C.paper:C.ink;
  return line(72,1266,1008,1266,f,1,'opacity=".3"')+
    text(72,1307,'일상에 잠깐, 틈',23,500,f)+text(540,1307,note,18,400,f,{anchor:'middle',maxWidth:530})+
    text(1008,1307,`${String(page).padStart(2,'0')} / 05`,23,500,f,{anchor:'end'});
}
function pill(x,y,w,label,dark=false) {
  return rect(x,y,w,42,dark?C.ink:C.lime,21)+text(x+w/2,y+29,label,21,500,dark?C.paper:C.ink,{anchor:'middle'});
}
function speech(x,y,w,label) {
  return `<path d="M ${x+24} ${y} H ${x+w-24} Q ${x+w} ${y} ${x+w} ${y+24} V ${y+54} Q ${x+w} ${y+78} ${x+w-24} ${y+78} H ${x+40} L ${x+12} ${y+100} L ${x+18} ${y+76} Q ${x} ${y+72} ${x} ${y+52} V ${y+24} Q ${x} ${y} ${x+24} ${y} Z" fill="${C.paper}" stroke="${C.ink}" stroke-width="3"/>`+text(x+w/2,y+50,label,27,500,C.ink,{anchor:'middle',maxWidth:w-32});
}
function cardBody(c,i) {
  if (c.layout==='photo-cover') {
    return image(c.photo,0,0,W,H)+
      `<defs><linearGradient id="coverShade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#111510" stop-opacity=".57"/><stop offset=".46" stop-color="#111510" stop-opacity=".08"/><stop offset="1" stop-color="#111510" stop-opacity=".88"/></linearGradient></defs>`+
      rect(0,0,W,H,'url(#coverShade)')+header(i,true)+pill(72,166,197,'SCROLL CULTURE')+
      text(66,316,c.title[0],96,700,C.paper,{maxWidth:944})+
      text(66,434,c.title[1],104,700,C.lime,{maxWidth:944})+
      rect(76,493,386,64,C.ink,32,'opacity=".76"')+text(269,536,'23:10  →  00:10',33,500,C.paper,{anchor:'middle',spacing:1})+
      pose(c.pose,59,760,330,330)+speech(354,820,245,c.speech)+
      lines(72,1151,c.body,40,56,500,C.paper)+footer(i,true,c.note);
  }
  if(c.layout==='data-photo') {
    return rect(0,0,W,H,C.paper)+header(i)+pill(72,164,303,c.eyebrow)+
      lines(68,302,c.title,86,105,700)+
      text(60,657,'76',254,700,C.ink)+text(390,650,'%',108,700,C.ink)+
      rect(548,495,432,8,C.lime)+lines(548,557,c.body,34,52,500,C.ink,442)+
      image(c.photo,72,704,936,410,24)+pose(c.pose,82,859,258,258)+
      speech(340,971,252,'잠깐이면 되겠지?')+
      lines(72,1173,c.source,23,34,400,C.muted)+footer(i,false,c.note);
  }
  if(c.layout==='illustrated-explainer') {
    return rect(0,0,W,H,C.ink)+header(i,true)+pill(72,164,377,c.eyebrow)+
      lines(69,290,c.title,76,100,700,C.paper)+
      image(c.image,72,445,936,586,22,'slice')+
      lines(72,1104,c.body,33,49,400,C.paper)+footer(i,true,c.note);
  }
  if(c.layout==='photo-question') {
    return rect(0,0,W,H,C.paper)+header(i)+pill(72,164,326,c.eyebrow)+
      lines(68,291,c.title,80,103,700)+
      image(c.photo,72,450,936,552,24)+pose(c.pose,748,747,254,254)+
      speech(324,864,438,c.question)+
      lines(72,1073,c.body,34,51,400,C.ink)+footer(i,false,c.note);
  }
  if(c.layout==='editorial-action') {
    return rect(0,0,W,H,C.lime)+header(i)+pill(72,164,304,c.eyebrow,true)+
      lines(68,290,c.title,76,99,700,C.ink)+
      rect(72,440,936,478,C.paper,24)+image(c.image,88,450,904,458,18,'meet')+
      rect(776,850,192,54,C.ink,27)+text(872,888,'10:00',31,700,C.paper,{anchor:'middle',spacing:2})+
      lines(72,992,c.body,34,49,400,C.ink)+
      rect(72,1133,936,83,C.ink,16)+text(540,1185,c.cta,32,500,C.paper,{anchor:'middle',maxWidth:872})+
      text(72,1246,c.source,19,400,C.ink,{maxWidth:936})+footer(i,false,'AI 생성 일러스트 · 편집부 제안');
  }
  throw new Error(`Unknown layout ${c.layout}`);
}
fs.mkdirSync(path.join(root,'export'),{recursive:true});
for(const [index,c] of config.cards.entries()) {
  currentCard=c.id;
  const s=svg(cardBody(c,index+1));
  const renderer=new Resvg(s,renderOptions);
  if(renderer.imagesToResolve().length) throw new Error('An image did not embed correctly.');
  const png=renderer.render();
  fs.writeFileSync(path.join(root,'export',c.id+'.svg'),s);
  fs.writeFileSync(path.join(root,'export',c.id+'.png'),png.asPng());
  console.log(c.id,`${png.width}x${png.height}`);
}
const issues=audits.filter(t=>t.x < 58 || t.x+t.width > W-58 || t.y<20 || t.y+t.height>H-25 || (t.maxWidth && t.width>t.maxWidth+1));
fs.writeFileSync(path.join(root,'export/layout-audit.json'),JSON.stringify({canvas:[W,H],checkedTextBlocks:audits.length,issues,text:audits},null,2));
if(issues.length) console.warn('Text bounds requiring inspection:',JSON.stringify(issues));

// Contact sheet: the five finished cards plus one concise brand panel.
currentCard='overview';
const overviewW=1752,overviewH=1620;
let board=rect(0,0,overviewW,overviewH,'#E4E5DC');
board+=text(44,65,'틈 / DIGITAL LIFE',35,700,C.ink)+text(1708,65,'01  SHORT-FORM CULTURE',22,500,C.ink,{anchor:'end',spacing:2});
const slots=[[36,102],[612,102],[1188,102],[36,858],[612,858]];
for(const [i,c]of config.cards.entries()) {
  const [x,y]=slots[i];
  board+=image('export/'+c.id+'.png',x,y,528,660,5,'meet')+text(x,y+700,`${String(i+1).padStart(2,'0')}   ${['공감의 표지','숫자로 보는 이유','캐릭터로 설명','독자에게 질문','작은 실험'][i]}`,24,500,C.ink);
}
board+=rect(1188,858,528,660,C.paper,5)+text(1230,928,'틈이와 읽는 일상',31,700,C.ink)+pose('notes',1277,974,335,335)+
  text(1230,1374,'사진 3장 + 캐릭터 장면 2장',22,500,C.ink)+text(1230,1418,'한글은 별도 조판 · 1080 × 1350',21,400,C.muted)+
  rect(1230,1460,52,20,C.ink,10)+rect(1294,1460,52,20,C.lime,10)+rect(1358,1460,52,20,C.paper,10,'stroke="#B7B9AE"');
const overview=svg(board,overviewW,overviewH);
fs.writeFileSync(path.join(root,'export/overview.png'),new Resvg(overview,renderOptions).render().asPng());

// Standalone raster poses: exact master-sheet crops via SVG viewports, with alpha intact.
for(const name of Object.keys(poses)) {
  fs.writeFileSync(path.join(root,'brand',`tteumi-${name}.png`),new Resvg(svg(pose(name,0,0,600,600),600,600),renderOptions).render().asPng());
}
currentCard='brand';
let brand=rect(0,0,1600,1350,C.paper)+text(64,103,'틈이',65,700,C.ink)+text(233,98,'TTEUMI / CHARACTER SHEET',25,500,C.ink,{spacing:2})+
  text(1536,98,'WORKING IDENTITY 01',22,400,C.muted,{anchor:'end'})+line(64,132,1536,132,C.ink);
const labels=['FRONT','SIDE','BACK','SLEEPY','QUESTION','DISCOVERY','SCROLL','NOTE','PAUSE'];
for(const [i,name]of Object.keys(poses).entries()) {
  const col=i%3,row=Math.floor(i/3),x=64+col*385,y=175+row*375;
  brand+=pose(name,x,y,300,300)+text(x+150,y+326,labels[i],19,500,C.muted,{anchor:'middle',spacing:2});
}
brand+=line(1214,180,1214,1240,C.line)+text(1250,235,'IDENTITY',22,700,C.ink)+
  lines(1250,295,['크림색 둥근 몸','라임색 책갈피','라임색 앞주머니','먹색 눈과 외곽선'],23,49,400,C.ink,290)+
  text(1250,620,'PALETTE',22,700,C.ink);
for(const [i,key]of ['ink','paper','lime'].entries())brand+=rect(1250,660+i*92,48,48,C[key],12,'stroke="#B7B9AE"')+text(1315,693+i*92,C[key],23,400,C.ink);
brand+=lines(1250,1050,['비율과 표식은 고정.','감정과 행동은 자유롭게.','작업명: 틈 / 틈이'],21,44,400,C.muted,290);
fs.writeFileSync(path.join(root,'brand/tteumi-character-sheet.png'),new Resvg(svg(brand,1600,1350),renderOptions).render().asPng());
console.log('Wrote overview, labelled character sheet, nine transparent poses and layout audit.');

// Self-contained preview: no server or cloud upload required.
const html=`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>틈 매거진 · 숏폼 카드뉴스</title><style>*{box-sizing:border-box}body{margin:0;background:#20231f;color:#f3f0e6;font-family:'Noto Sans KR','Malgun Gothic',sans-serif;padding:36px}header{max-width:1300px;margin:0 auto 32px;display:flex;align-items:end;justify-content:space-between;gap:24px}h1{font-size:38px;margin:0}p{line-height:1.7;color:#bfc3b7}a{color:#c7ed63;text-decoration:none}.grid{max-width:1300px;margin:auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:28px}.grid img{width:100%;height:auto;display:block;border-radius:8px}figure{margin:0}figcaption{padding:14px 0;color:#bfc3b7;font-size:14px}.brand{max-width:1300px;margin:48px auto}.brand img{max-width:100%;border-radius:8px}nav{line-height:2}@media(max-width:600px){body{padding:18px}header{display:block}}</style><header><div><h1>틈 / 1분만 보려다, 오늘도 1시간.</h1><p>캐릭터 시트 · 사진과 일러스트 · 재사용 템플릿 · 카드뉴스 5장<br>‘틈’과 ‘틈이’는 작업명입니다. 이미지에는 AI 생성 표시를 넣었습니다.</p></div><nav><a href="export/overview.png">5장 한눈에 보기 ↗</a><br><a href="brand/tteumi-character-sheet.png">캐릭터 시트 ↗</a><br><a href="README.md">구성·출처·수정 방법 ↗</a></nav></header><main class="grid">${config.cards.map((c,i)=>`<figure><a href="export/${c.id}.png"><img src="export/${c.id}.png" alt="${esc(c.title.join(' '))}"></a><figcaption>${i+1}/5 · ${esc(c.layout)} · <a href="export/${c.id}.png" download>PNG</a> / <a href="export/${c.id}.svg" download>SVG</a></figcaption></figure>`).join('')}</main><section class="brand"><h2>캐릭터 시트</h2><img src="brand/tteumi-character-sheet.png" alt="틈이 9포즈 캐릭터 시트"><p>문구와 이미지는 template/content.json, 배치와 서체는 template/render.mjs에서 수정할 수 있습니다.</p></section></html>`;
fs.writeFileSync(path.join(root,'preview.html'),html);
