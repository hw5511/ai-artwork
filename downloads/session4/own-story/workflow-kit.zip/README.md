# 클립 3개 생성 준비 결과

현재 단계는 **오프라인 준비 완료 / 미제출**이다. 로그인·계정 조회·업로드·생성·업스케일·크레딧 사용은 수행하지 않았다.

- 출력: `clip1.api.json`, `clip2.api.json`, `clip3.api.json`.
- 출발점: CLI로 가져온 갤러리 `video_minimax_h3_r2v` (`video_minimax_h3_r2v.ui.json`).
- `MiniMaxH3ReferenceToVideo`: width=1280, height=720, length=243. `CreateVideo`: 24fps.
- 템플릿의 turbo LoRA `minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors`, strength=1, turbo 스위치=true, 선택된 스텝=4. 템플릿의 res_multistep/simple 유지.
- 비디오 VAE: `minimax_h3_video_vae_fp16.safetensors`. 보관된 Cloud `VAELoader` 목록과 `object_info` 스냅샷에서 확인했다. 이번 작업에서 Cloud 목록을 새로 조회하지 않았다.
- 프롬프트는 `session4/prompts/clip1.txt`~`clip3.txt`를 개행까지 그대로 반영했다.
- `session4/references.json`의 순서를 그대로 `ref_images.ref_image_0`~`ref_image_4`에 연결했다. 인물 → 제품 전체 → 해당 클립 디테일 → 장소 → 스토리보드 순서다. 클립 2의 디테일은 다이얼이며 셔터 참조를 추가하지 않았다.
- 243프레임은 17×14+5이며 24fps에서 10.125초다. 결과 회수 후 CPU ffmpeg로 영상 앞 240프레임/10초와 같은 구간의 오디오를 보존한다. 이 트리밍도 아직 실행하지 않았다.

## 검증과 CLI 출력

세 클립 모두 Comfy CLI 1.22.0의 `workflow validate --input object-info.cloud.snapshot.json` 결과 **valid=true, errors=0, warnings=0**이다. `run --where cloud --print-prompt`의 실행 그래프가 저장된 API 그래프에서 compose 출처 메타데이터를 제외한 내용과 일치했다. 원문 프롬프트, 참조 순서, 입력 파일 SHA-256도 확인했다. 상세 결과는 `preflight-report.json`, CLI 원문은 `evidence/clip*.validate.stdout.jsonl`과 `evidence/clip*.print-prompt.stdout.jsonl`에 있다.

설치된 CLI의 Cloud 실행 경로는 API 입력의 `--print-prompt`에서도 조기 반환 전에 `object_info`를 가져온다. `offline_cli.py`는 해당 카탈로그 로드만 로컬 스냅샷으로 대체하고, 인증 대상 해석과 소켓 네트워크 접근은 차단한다. 설치된 CLI 파일을 수정하지 않았으며 Comfy CLI 자체의 compose/validate/print 동작을 사용했다. Cloud 서버의 실시간 검증·파일 접근·실제 렌더 성공을 확인한 결과는 아니다.

재현은 작업 폴더에서 `python -X utf8 session4/cloud/prepare.py`로 가능하다. 이 스크립트는 준비 작업만 허용하고 `run`은 `--where cloud --print-prompt`일 때만 허용한다. 템플릿은 decompose한 소스 프래그먼트와 클립별 YAML로 관리하고, API 파일은 compose로 다시 만든다. CLI 1.22의 희소 노드 ID 충돌을 피하기 위해 소스 프래그먼트 ID를 연속 번호로 바꿨고, `SaveVideo`는 올바른 `format.codec`를 사용하는 별도 소스 프래그먼트로 보존했다.

## 견적

**생성·업스케일 총액: 미확정.** CLI discover에 이 경로의 숫자 GPU 견적 명령이 없고, validate/print-prompt도 숫자 GPU 견적을 반환하지 않았다. 계정이나 견적 API를 별도로 조회하지 않았다.

수업 비용 근거 `evidence/cost-sources.txt`의 실측 단가를 적용한다.

`예상 총 크레딧 ≈ 0.2732 × (클립 3개 생성 GPU 사용 초의 합 + 업스케일 GPU 사용 초의 합)`

생성 GPU 사용 시간과 업스케일 GPU 사용 시간은 아직 알 수 없다. 영상 재생 시간 10.125초 또는 사용 구간 10초를 GPU 사용 시간에 대입하지 않는다. `partner_nodes=[]`, `spends_credits=false` 또는 파트너 견적 0은 파트너 호출 비용만 가리키며, Cloud GPU 시간 요금은 발생한다. 이를 무료나 총액 0으로 해석하지 않는다. 현재 720p 생성 워크플로에는 업스케일 노드를 넣지 않았다.

## 예산 확인 뒤의 제출 계획

1. 생성 3개와 필요한 업스케일의 예산 상한을 확인한다. 현재는 계정 상태·잔액·동시 실행 수를 조회하거나 가정하지 않는다. 제출 단계에서 계정 확인이 필요하면 현재의 계정 조회 금지 범위도 먼저 해제되어야 한다.
2. 업로드가 허용된 단계에서만 참조 이미지를 업로드한다. `preflight-report.json`의 참조 매핑에 실제 `cloud_name`을 기록하고, 각 YAML의 입력 경로를 실제 Cloud 파일명으로 바꿔 다시 compose한다. 현재 API의 `LoadImage.image`는 **로컬 경로이며 Cloud 파일명 바인딩은 미완료**다.
3. 확정된 파일명과 최신 Cloud 스키마로 검증하고, 다시 `--where cloud --print-prompt`를 검토한 다음 허용된 예산 안에서 제출한다. 첫 결과의 품질과 실제 GPU 사용 시간을 확인한 후 나머지를 진행한다.
4. 결과 회수 후 각 클립의 앞 10초를 오디오와 함께 잘라 사용한다. 업스케일은 범위와 예산이 확인된 뒤 진행하며, 그 GPU 사용 시간도 같은 요금식에 더한다.
5. **오류 1026이면 CLI 오류 원문(stdout/stderr 및 error 객체)을 그대로 제시하고 자동 재시도를 멈춘다.** 프롬프트 자동 변경이나 자동 재제출은 하지 않는다. 현재는 제출하지 않아 1026 응답도 발생하지 않았다.
