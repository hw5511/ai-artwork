"""Prepare/run locally: python session4/final/concat_30s.py --original-dir PATH

No third-party Python packages. Inputs are checked before ffmpeg is launched.
Originals must be the corresponding untrimmed clip1.mp4 ... clip3.mp4, with
the same timeline as the upscaled files. Default: session4/originals.
"""
import argparse
import csv
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent.parent
FINAL = ROOT / "final"


def run(args):
    result = subprocess.run([str(x) for x in args], capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    if result.returncode:
        raise RuntimeError(f"Command failed: {args[0]}\n{result.stderr[-8000:]}")
    return result.stdout


def probe(path, count=False):
    args = ["ffprobe", "-v", "error"]
    if count:
        args += ["-count_frames"]
    return json.loads(run(args + ["-show_streams", "-show_format", "-of", "json", path]))


def stream(info, kind):
    return next((s for s in info["streams"] if s["codec_type"] == kind), None)


def duration(s):
    # Do not use container duration to conceal a short video/audio stream.
    if s.get("duration_ts") is not None and s.get("time_base"):
        num, den = map(int, s["time_base"].split("/"))
        return float(s["duration_ts"]) * num / den
    return float(s.get("duration", "nan"))


def require_ten_seconds(info, path, audio=True):
    for kind in (["video", "audio"] if audio else ["video"]):
        s = stream(info, kind)
        if s is None:
            raise RuntimeError(f"{path}: no {kind} stream; stopping without replacement.")
        seconds = duration(s)
        if not math.isfinite(seconds) or seconds < 10:
            raise RuntimeError(f"{path}: {kind} duration={seconds}; need at least 10 seconds.")


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def review_points():
    # Midpoints cover each planned shot; neighboring frames expose hard cuts.
    # These are planned boundaries, not claims about cuts in absent footage.
    plan = ROOT / "shots.json"
    cuts = [[0, 3, 6], [0, 2, 4, 7], [0, 3, 6]]
    if plan.is_file():
        data = json.loads(plan.read_text(encoding="utf-8-sig"))
        cuts = [c["hard_cut_times_seconds"] for c in data["clips"]]
    points = []
    for i in range(3):
        boundaries = sorted({0, 10, *(float(t) for t in cuts[i] if 0 <= float(t) < 10)})
        indices = {0, 239}
        for left, right in zip(boundaries, boundaries[1:]):
            indices.add(round((left + right) * 12))
        for boundary in boundaries[1:-1]:
            n = round(boundary * 24)
            indices.update((n - 1, n, n + 1))
        for n in sorted(indices):
            points.append((i + 1, n))
    return points


def extract_frames(path, indices, dest, prefix):
    dest.mkdir(parents=True, exist_ok=True)
    indices = sorted(set(indices))
    select = "+".join(f"eq(n\\,{n})" for n in indices)
    # Normalize presentation origin, never speed. The same 24-fps sampling
    # grid is used for originals, upscaled files, and the final encode.
    vf = f"setpts=PTS-STARTPTS,fps=24:start_time=0,select='{select}'"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
         "-hwaccel", "none", "-i", path, "-map", "0:v:0", "-an", "-sn", "-dn",
         "-vf", vf, "-frames:v", len(indices), "-fps_mode", "vfr",
         "-start_number", "0", dest / f"{prefix}-%03d.png"])
    for ordinal, n in enumerate(indices):
        source = dest / f"{prefix}-{ordinal:03d}.png"
        if not source.is_file():
            raise RuntimeError(f"Missing review frame: {path}, frame {n}")
        source.rename(dest / f"{prefix}-frame{n:03d}.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-dir", type=Path, default=ROOT / "originals")
    options = parser.parse_args()
    inputs = [ROOT / "upscaled" / f"clip{i}.mp4" for i in range(1, 4)]
    missing = [str(p) for p in inputs if not p.is_file()]
    if missing:
        raise RuntimeError("Missing inputs; ffmpeg was NOT launched:\n" + "\n".join(missing))
    for executable in ("ffprobe", "ffmpeg"):
        if not shutil.which(executable):
            raise RuntimeError(f"{executable} is not on PATH.")

    # Probe all three before any encoding; keep inspectable reports.
    FINAL.mkdir(parents=True, exist_ok=True)
    infos = [probe(p) for p in inputs]
    save_json(FINAL / "input-ffprobe.json", dict(zip(map(str, inputs), infos)))
    for p, info in zip(inputs, infos):
        require_ten_seconds(info, p)

    originals = [options.original_dir.resolve() / p.name for p in inputs]
    missing_originals = [str(p) for p in originals if not p.is_file()]
    if missing_originals:
        raise RuntimeError("Originals required for comparison. Supply --original-dir; "
                           "ffmpeg was NOT launched:\n" + "\n".join(missing_originals))
    original_infos = [probe(p) for p in originals]
    save_json(FINAL / "original-ffprobe.json", dict(zip(map(str, originals), original_infos)))
    for p, info in zip(originals, original_infos):
        require_ten_seconds(info, p, audio=False)

    output = FINAL / "my-30s.mp4"
    partial = FINAL / "my-30s.partial.mp4"
    review = FINAL / "comparison-frames"
    # Never overwrite existing deliverables or evidence silently.
    for p in (output, partial, review):
        if p.exists():
            raise RuntimeError(f"Output already exists: {p}; move it before rerunning.")

    filters = []
    for i in range(3):
        filters += [
            f"[{i}:v:0]setpts=PTS-STARTPTS,trim=duration=10,"
            "scale=2560:1440:force_original_aspect_ratio=decrease:flags=lanczos,"
            "pad=2560:1440:(ow-iw)/2:(oh-ih)/2,setsar=1,"
            f"fps=24:start_time=0,trim=end_frame=240,format=yuv420p[v{i}]",
            f"[{i}:a:0]asetpts=PTS-STARTPTS,atrim=duration=10,aresample=48000,"
            f"aformat=sample_fmts=fltp:channel_layouts=stereo[a{i}]",
        ]
    filters.append("[v0][a0][v1][a1][v2][a2]concat=n=3:v=1:a=1[v][a]")
    args = ["ffmpeg", "-hide_banner", "-loglevel", "warning", "-nostdin", "-n"]
    for p in inputs:
        args += ["-hwaccel", "none", "-i", p]
    args += ["-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
             "-sn", "-dn", "-map_metadata", "-1", "-map_chapters", "-1",
             "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
             "-fps_mode", "cfr", "-r", "24", "-video_track_timescale", "24000",
             "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
             "-t", "30", "-movflags", "+faststart", partial]
    save_json(FINAL / "ffmpeg-command.json", list(map(str, args)))
    print("Encoding first 10 seconds of each input with CPU libx264...", flush=True)
    run(args)

    result = probe(partial, count=True)
    save_json(FINAL / "output-ffprobe.json", result)
    v, a = stream(result, "video"), stream(result, "audio")
    checks = {
        "container_30_seconds": abs(float(result["format"]["duration"]) - 30) < 0.000001,
        "video_30_seconds": abs(duration(v) - 30) < 0.000001,
        "video_2560x1440": (v["width"], v["height"]) == (2560, 1440),
        "video_24fps": v["avg_frame_rate"] == "24/1" and v["r_frame_rate"] == "24/1",
        "decoded_720_frames": int(v.get("nb_read_frames", -1)) == 720,
        "h264": v["codec_name"] == "h264",
        "aac": a is not None and a["codec_name"] == "aac",
        "audio_30_seconds": a is not None and abs(duration(a) - 30) < 0.000001,
    }
    save_json(FINAL / "verification.json", checks)
    if not all(checks.values()):
        raise RuntimeError(f"Validation failed; partial output retained: {checks}")
    partial.rename(output)

    print("Validation passed. Extracting matched review frames...", flush=True)
    points = review_points()
    for i in range(1, 4):
        indices = [n for clip, n in points if clip == i]
        extract_frames(originals[i - 1], indices, review / "original", f"clip{i}")
        extract_frames(inputs[i - 1], indices, review / "upscaled", f"clip{i}")
    final_indices = [(clip - 1) * 240 + n for clip, n in points]
    # Includes 239/240 and 479/480: both sides of the two concatenation cuts.
    extract_frames(output, final_indices, review / "final", "timeline")
    with (review / "index.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["clip", "local_frame_24fps", "local_seconds", "final_seconds",
                         "original", "upscaled", "final"])
        for clip, n in points:
            timeline = (clip - 1) * 240 + n
            writer.writerow([clip, n, f"{n / 24:.9f}", f"{timeline / 24:.9f}",
                             f"original/clip{clip}-frame{n:03d}.png",
                             f"upscaled/clip{clip}-frame{n:03d}.png",
                             f"final/timeline-frame{timeline:03d}.png"])
    (review / "README.txt").write_text(
        "Matched full-frame PNGs on a common 24-fps presentation-time grid.\n"
        "Originals retain native dimensions; no synthetic detail or labels are added.\n"
        "Compare face identity/texture, camera buttons/dial/logo, light/shadows.\n"
        "Shot midpoints and neighbors of planned cuts come from shots.json.\n"
        "Inspect cut pairs 239/240 and 479/480 in final/ for direct joins.\n"
        "Timing assumes the original and upscaled versions share their start point.\n"
        "Frames are evidence for manual review, not an automated visual-quality verdict.\n",
        encoding="utf-8")
    print(f"Complete: {output}\n30 seconds, 2560x1440, 24 fps, 720 frames, H.264/AAC.")
    print(f"Comparison frames: {review}")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        sys.exit(1)
