# SeedVR2 업스케일 준비 결과

갤러리 `utility_seedvr2_3b_int8_upscale_video`에서 만든 API 파일 3개를 저장했다. **오프라인 준비 완료 / 입력 없음으로 실행 중단 / 미제출** 상태다.

| API | 입력 경로 (그대로 보존) | 상태 |
|---|---|---|
| `upscale1.api.json` | `session4/clips/clip1-720.mp4` | 없음 |
| `upscale2.api.json` | `session4/clips/clip2-720.mp4` | 없음 |
| `upscale3.api.json` | `session4/clips/clip3-720.mp4` | 없음 |

2배 확대(`scale by multiplier`, multiplier=2), `split_latent=true`, 원본 오디오·FPS 연결을 확인했다. 템플릿의 비디오 트리밍 스위치는 꺼져 있어 입력 전체를 사용한다. 1280×720 입력이면 목표는 2560×1440이다. 실제 입력 크기·길이·오디오 유무는 파일이 없어 확인하지 못했다. 오디오 연결 보존은 원본 오디오 비트스트림의 무손실 복사를 보장하는 의미는 아니다.

모델은 갤러리의 `seedvr2_3b_int8_convrot.safetensors`, VAE는 `seedvr2_ema_vae_fp16.safetensors`를 유지했다. 템플릿을 CLI `decompose`로 소스 프래그먼트로 투영한 뒤 `blueprints/upscale1.yaml`~`upscale3.yaml`을 CLI `compose`로 빌드했다. 기존의 스키마 호환 `save_video` 소스 프래그먼트를 사용했다. API 파일은 직접 수정하지 않았다.

세 파일 모두 저장된 Cloud 스키마로 `workflow validate --input object-info.cloud.snapshot.json`을 통과했다(**valid=true, errors=0, warnings=0**). `run --where cloud --print-prompt` 결과는 compose 메타데이터를 제외한 API 그래프와 일치했다.

설치된 CLI 1.22.0은 `--print-prompt`에서도 반환 전에 카탈로그를 읽는다. 기존 `offline_cli.py`로 카탈로그 읽기만 로컬 스냅샷으로 대체하고 인증 대상 해석과 소켓 접근을 차단했다. 이는 실시간 Cloud 검증이나 실제 파일 접근·렌더 성공 검증이 아니다. 입력 경로는 로컬 경로 자리표시자이며 Cloud 파일명으로 바인딩되지 않았다. 스키마 통과를 제출 준비 완료로 해석하지 않는다.

로그인·계정 조회·업로드·제출·GPU 실행·크레딧 사용은 수행하지 않았다. 갤러리 메타데이터 조회와 템플릿 가져오기만 수행했다. 상세 결과는 `upscale-preflight-report.json`, CLI 원문은 `evidence/upscale*.validate.stdout.jsonl`, `evidence/upscale*.print-prompt.stdout.jsonl`에 있다.

## 비용

**업스케일 추가 비용 ≈ 업스케일 GPU 사용 초의 합 × 0.2732크레딧. 총액 미확정.**

요청된 근사 단가와 기존 `evidence/cost-sources.txt`의 기록을 적용했다. 이번 작업에서 계정·잔액·견적을 조회하거나 단가를 새로 확인하지 않았다. GPU 사용 시간은 아직 알 수 없다. 영상 재생 시간을 GPU 사용 시간으로 대입하지 않는다.

기존 720p 생성까지 포함한 전체 비용도 미확정이다:

`전체 크레딧 ≈ 0.2732 × (생성 GPU 사용 초의 합 + 업스케일 GPU 사용 초의 합)`

파트너 호출 비용 0 또는 `spends_credits=false`는 Cloud GPU 무료를 뜻하지 않는다.

## 예산 확인 뒤 진행 순서 — 아직 실행하지 않음

1. 입력 3개가 존재하는지 확인하고 크기·길이·FPS·오디오를 점검한다. 업스케일 추가 예산과 생성 포함 총 예산 상한, 업로드·유료 실행 허용 범위를 확인한다. 현재의 로그인·계정 조회 금지는 유지된다.
2. 업로드가 허용된 다음 입력 비디오를 `comfy --json upload session4/clips/clip1-720.mp4 --where cloud` 형식으로 각각 업로드한다. 응답의 `data.uploads[0].cloud_name`을 기록한다. 인증이 필요하면 별도 허용된 단계에서 처리한다.
3. 각 `blueprints/upscaleN.yaml`의 `source.params.file`을 실제 `cloud_name`으로 바꾸고 `comfy --json workflow compose session4/cloud/blueprints/upscaleN.yaml --lib session4/cloud/fragments --out session4/cloud/upscaleN.api.json`으로 다시 빌드한다. Cloud의 `LoadVideo`가 업로드된 파일을 실제로 읽을 수 있는지 최신 스키마와 파일명으로 확인한다. 기존 스킬은 Cloud 비디오 목록에 업로드가 반영되지 않을 수 있다고 기록하므로, 파일 접근이 확인되지 않으면 제출을 중단한다.
4. 최신 스키마로 검증하고 `comfy --json run --workflow session4/cloud/upscaleN.api.json --where cloud --print-prompt`를 검토한다. 허용된 예산 내에서 첫 클립을 `--print-prompt` 없이 제출하고 반환된 `prompt_id`를 보관한다. 완료 후 실제 GPU 시간·비용·화질을 확인하고 남은 예산 안에서 나머지를 진행한다.
5. `comfy --json jobs watch <prompt_id> --where cloud`로 완료를 확인한 뒤 `comfy --json download <prompt_id> --where cloud --out-dir session4/clips/upscaled`로 회수한다. 결과 크기, 전체 프레임·FPS·길이, 원본 오디오 유지와 싱크를 확인한다.

오류 1026이면 CLI 오류 원문을 보존·제시하고 자동 재시도·프롬프트 변경·재제출을 멈춘다.

현재 로컬 준비만 재현하려면 작업 폴더에서 `python -X utf8 session4/cloud/prepare_upscale.py`를 실행한다. 이 스크립트는 입력 파일이 생겨도 업로드·제출하지 않으며, 로컬 경로를 다시 사용하므로 향후 Cloud 파일명 바인딩 후에는 재실행하지 않는다.
