검증한 템플릿과 API 준비 파일. 참조 파일명은 입력 자리입니다. 본인 references.json을 반영하고 업로드 cloud_name으로 바꾼 뒤 미리보기를 다시 확인하세요. 제출·GPU 실행 미실행. Cloud GPU는 유료 시간 과금입니다.
